"""Evidence-led figures at their final two-column publication size.

All plotted results come from JSON artifacts. The method diagram alone is
schematic. The teaser uses unmodified simulator frames, not generated imagery.
"""
from pathlib import Path
import json

import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "ICRA/figures"
BLUE, ORANGE, GRAY = "#0072B2", "#B95018", "#59636D"
WIDTH = 7.12


def save(fig, name):
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{name}.pdf")
    fig.savefig(OUT / f"{name}.png", dpi=220)
    plt.close(fig)


def teaser():
    fig = plt.figure(figsize=(WIDTH, 1.94))
    frame_ids = [1, 2, 3, 5]
    labels = ["Initial scene", "Kettle grasped", "Above the burner", "Task complete"]
    for i, (frame_id, label) in enumerate(zip(frame_ids, labels)):
        ax = fig.add_axes([.005 + .251 * i, .15, .237, .73])
        ax.imshow(Image.open(ROOT / f"paper/figures/kettle_storyboard_frames/official/frame_{frame_id:02d}.png"))
        ax.axis("off")
        ax.set_title(label, fontsize=9, pad=5)
    fig.text(.5, .048, "Pick up the kettle   →   Place it on the stove   →   Turn on the burner",
             ha="center", va="center", fontsize=10)
    save(fig, "teaser_v2")


def method():
    fig = plt.figure(figsize=(WIDTH, 1.70))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, WIDTH)
    ax.set_ylim(0, 1.7)
    ax.axis("off")
    ax.text(.02, 1.52, "Program", fontsize=10, weight="bold")
    ax.text(.02, 1.18, "1  Put soup in basket", fontsize=9, color=ORANGE)
    ax.text(.02, .91, "2  Put tomato in basket", fontsize=9, color=GRAY)
    ax.text(.02, .35, "Image + robot state", fontsize=9)
    ax.add_patch(Rectangle((2.06, .58), .88, .66, fill=False, ec=GRAY, lw=1))
    ax.text(2.50, .91, "VLA", ha="center", va="center", fontsize=11)
    for y in [.35, 1.18]:
        ax.annotate("", (2.02, .91), (1.72, y),
                    arrowprops=dict(arrowstyle="->", color=GRAY, lw=1))
    ax.annotate("", (3.33, .91), (2.98, .91), arrowprops=dict(arrowstyle="->", lw=1, color=GRAY))
    ax.text(3.43, 1.52, "Motion segment", fontsize=10, weight="bold")
    ax.text(3.43, 1.13, r"Shape: $c_0,\ldots,c_7$", fontsize=9)
    ax.text(3.43, .81, r"Gripper: $g_0,\ldots,g_7$", fontsize=9)
    ax.text(3.43, .49, r"Duration: $\widehat{T}$", fontsize=9)
    ax.annotate("", (5.10, .91), (4.77, .91), arrowprops=dict(arrowstyle="->", lw=1, color=GRAY))
    ax.text(5.23, 1.52, "Decode", fontsize=10, weight="bold")
    ax.text(5.23, 1.11, r"$p(u)=\sum_i B_i(u)c_i$", fontsize=11)
    ax.text(5.23, .78, r"$h=\mathrm{round}(\alpha\rho\widehat{T})$", fontsize=10)
    ax.text(5.23, .42, "Difference → robot actions", fontsize=9)
    ax.text(3.56, .075, "Several motion segments execute each language clause.",
            ha="center", fontsize=9, color=GRAY)
    save(fig, "method_v2")


def language(stats):
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.25))
    fig.subplots_adjust(left=.085, right=.98, bottom=.22, top=.80, wspace=.39)
    ax = axes[0]
    for key, label, color, offset in [("A", "Waypoint", BLUE, -.035), ("C", "Event spline", ORANGE, .035)]:
        rows = stats["comparisons"][key + "_fixed_clock"]["per_seed"]
        data = np.array([[r["original_successes"], r["clause_successes"]] for r in rows])
        for i, values in enumerate(data):
            ax.plot(np.array([0, 1]) + offset, values, color=color, alpha=.3, lw=.9)
        ax.plot(np.array([0, 1]) + offset, data.mean(0), marker="o", ms=4.5,
                color=color, lw=1.6, label=label)
        ax.annotate(f"{data.mean(0)[1]:.1f}%", (1 + offset, data.mean(0)[1]),
                    xytext=(5, 0), textcoords="offset points", va="center", color=color, fontsize=9)
    ax.set_xlim(-.20, 1.42)
    ax.set_ylim(0, 65)
    ax.set_xticks([0, 1], ["Whole-task labels", "Clause labels"])
    ax.set_ylabel("Scheduled success (%)")
    ax.set_yticks([0, 20, 40, 60])
    ax.set_title("(a) Same clause schedule at test time", loc="left", fontsize=9, pad=9)
    ax.legend(frameon=False, fontsize=8, loc="upper left", handlelength=1.3)
    ax = axes[1]
    x = np.arange(3)
    w = .32
    for key, label, color, shift in [("A", "Waypoint", BLUE, -w / 2), ("C", "Event spline", ORANGE, w / 2)]:
        rows = stats["comparisons"][key + "_fixed_clock"]["per_seed"]
        values = [100 * r["clause_minus_original"] for r in rows]
        ax.bar(x + shift, values, w, color=color, label=label)
        for xi, yi in zip(x + shift, values):
            ax.text(xi, yi + 1, f"{yi:.0f}", ha="center", va="bottom", fontsize=8)
    ax.set_ylim(0, 57)
    ax.set_xticks(x, ["1000", "1001", "1002"])
    ax.set_xlabel("Training seed")
    ax.set_ylabel("Clause-label gain (pp)")
    ax.set_yticks([0, 20, 40])
    ax.set_title("(b) Larger label effect for the spline head", loc="left", fontsize=9, pad=9)
    save(fig, "language_v2")


def clock(calvin):
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.25))
    fig.subplots_adjust(left=.085, right=.98, bottom=.23, top=.83, wspace=.39)
    ax = axes[0]
    for key, label, color, style in [("A", "Waypoint, native", BLUE, "-"),
            ("C", "Spline, native", GRAY, "--"), ("U", "Spline, retimed", ORANGE, "-")]:
        ax.plot(np.arange(1, 6), calvin[key]["sr_pooled"], style,
                marker="o", ms=3.5, lw=1.3, color=color, label=label)
    ax.set_ylim(0, 80)
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel("Consecutive tasks completed")
    ax.set_ylabel("Chains reaching depth (%)")
    ax.set_title("(a) Official CALVIN chains", loc="left", fontsize=9, pad=9)
    ax.legend(frameon=False, fontsize=8, handlelength=1.5)
    ax = axes[1]
    x = np.arange(3)
    for i in range(3):
        ax.plot([i, i], [calvin["C"]["per_seed"][i], calvin["U"]["per_seed"][i]], color=GRAY, alpha=.5, lw=1)
    for key, color, marker in [("A", BLUE, "s"), ("C", GRAY, "o"), ("U", ORANGE, "o")]:
        ax.scatter(x, calvin[key]["per_seed"], color=color, marker=marker, s=24, zorder=3)
    ax.set_xticks(x, ["1000", "1001", "1002"])
    ax.set_xlim(-.45, 2.45)
    ax.set_ylim(1.1, 1.9)
    ax.set_yticks([1.2, 1.4, 1.6, 1.8])
    ax.set_xlabel("Training seed")
    ax.set_ylabel("Mean completed tasks")
    ax.set_title("(b) Retiming improves all spline seeds", loc="left", fontsize=9, pad=9)
    save(fig, "clock_v2")


def main():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
        "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": .7, "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.facecolor": "white"})
    stats = json.loads((ROOT / "outputs/language_clause_exact/locked_3seed_factorial_2327539.json").read_text())
    assert stats["claim_ready"]
    calvin = json.loads((ROOT / "scripts/figures/data/calvin_seeded_final.json").read_text())
    teaser()
    method()
    language(stats)
    clock(calvin)


if __name__ == "__main__":
    main()
